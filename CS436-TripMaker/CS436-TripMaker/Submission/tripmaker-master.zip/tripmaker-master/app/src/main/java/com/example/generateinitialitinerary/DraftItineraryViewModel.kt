package com.example.TripMaker

import androidx.lifecycle.ViewModel

class DraftItineraryViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}